#!/bin/bash
echo "Avvio di ZIP Media Separator (GUI)..."
python3 zip_processor_gui.py